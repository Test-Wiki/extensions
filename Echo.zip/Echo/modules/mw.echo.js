( function ( mw ) {
	mw.echo = mw.echo || {};
	mw.echo.config = mw.echo.config || { maxPrioritizedActions: 2 };
} )( mediaWiki );
