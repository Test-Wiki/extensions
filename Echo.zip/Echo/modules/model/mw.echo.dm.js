( function ( mw ) {
	mw.echo.dm = {};
} )( mediaWiki );
