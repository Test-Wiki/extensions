CREATE INDEX /*i*/echo_event_page_id ON /*_*/echo_event (event_page_id);
