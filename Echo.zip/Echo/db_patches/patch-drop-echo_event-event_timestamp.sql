ALTER TABLE /*_*/echo_event DROP event_timestamp;
