-- drop this table because subscription is not supported
DROP TABLE /*_*/echo_subscription;
