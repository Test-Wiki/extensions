ALTER TABLE /*_*/echo_event ADD event_page_id int unsigned;
