<?php

class EchoEmailFormat {
	const HTML = 'html';
	const PLAIN_TEXT = 'plain-text';
}
