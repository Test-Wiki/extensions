# Refreshed
A new clean, modern MediaWiki skin used on Brickimedia.

# Documentation
Read the documentation for this MediaWiki skin on [MediaWiki.org](https://www.mediawiki.org/wiki/Skin:Refreshed).
