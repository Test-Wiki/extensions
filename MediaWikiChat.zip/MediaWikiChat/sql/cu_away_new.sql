ALTER TABLE /*_*/chat_users MODIFY cu_away binary(12)
