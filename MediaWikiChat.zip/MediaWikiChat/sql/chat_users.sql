CREATE TABLE /*_*/chat_users (
  cu_user_id int(10),
  cu_timestamp binary(12),
  cu_away binary(12)
) /*$wgDBTableOptions*/;