MediaWikiChat
=============

A lightweight chat extension for mediawiki

Developed for Brickimedia, but please feel free to use it on your own projects.
