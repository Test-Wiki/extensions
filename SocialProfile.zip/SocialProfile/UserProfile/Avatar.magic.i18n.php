<?php
/**
 * Internationalization file for the {{#avatar}} parser function.
 *
 * @file
 */

$magicWords = array();

/** English */
$magicWords['en'] = array(
	'avatar' => array( 0, 'avatar' ),
);