<?php

class AFPException extends MWException {
}
